import Form from './Form';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Formulário</h1>
      <Form/>
   
    </div>
  );
}

export default App;
